from django.apps import AppConfig


class NeomodelAdminConfig(AppConfig):
    name = 'neomodel_admin'
